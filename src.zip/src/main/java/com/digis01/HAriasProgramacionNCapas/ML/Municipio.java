
package com.digis01.HAriasProgramacionNCapas.ML;

public class Municipio {
private int Idmunicipio;
private String Nombre;
public Estado Estado;

    public int getIdMunicipio() {
        return Idmunicipio;
    }

    public void setIdMunicipio(int Idmunicipio) {
        this.Idmunicipio = Idmunicipio;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public Estado getEstado() {
        return Estado;
    }

    public void setEstado(Estado Estado) {
        this.Estado = Estado;
    }

  


}
