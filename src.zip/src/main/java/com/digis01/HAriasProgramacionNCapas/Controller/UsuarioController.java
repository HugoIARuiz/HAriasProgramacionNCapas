package com.digis01.HAriasProgramacionNCapas.Controller;

import com.digis01.HAriasProgramacionNCapas.DAO.ColoniaDAOImplementation;
import com.digis01.HAriasProgramacionNCapas.DAO.DireccionDAOImplementation;
import com.digis01.HAriasProgramacionNCapas.DAO.EstadoDAOImplementation;
import com.digis01.HAriasProgramacionNCapas.DAO.MunicipioDAOImplementation;
import com.digis01.HAriasProgramacionNCapas.DAO.PaisDAOImplementation;
import com.digis01.HAriasProgramacionNCapas.DAO.RolDAOImplementation;
import com.digis01.HAriasProgramacionNCapas.DAO.UsuarioDAOImplementation;
import com.digis01.HAriasProgramacionNCapas.ML.Colonia;
import com.digis01.HAriasProgramacionNCapas.ML.Direccion;
import com.digis01.HAriasProgramacionNCapas.ML.Result;
import com.digis01.HAriasProgramacionNCapas.ML.Rol;
import com.digis01.HAriasProgramacionNCapas.ML.Usuario;
import com.digis01.HAriasProgramacionNCapas.ML.UsuarioDireccion;
import jakarta.validation.Valid;
import java.util.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

@Controller
@RequestMapping("/Usuario")
public class UsuarioController {

    @Autowired
    private UsuarioDAOImplementation usuarioDAOImplementation;
    @Autowired
    private RolDAOImplementation rolDAOImplementation;
    @Autowired
    private DireccionDAOImplementation direccionDaOImplementation;
    @Autowired
    private PaisDAOImplementation paisDAOImplementation;
    @Autowired
    private EstadoDAOImplementation estadoDAOImplementation;
    @Autowired
    private MunicipioDAOImplementation municipioDAOImplementation;
    @Autowired
    private ColoniaDAOImplementation coloniaDAOImplementation;

    // Model y ModelAttribute
    @GetMapping("index")
    public String Index(Model model) {

        Result result = usuarioDAOImplementation.GetAll();
        model.addAttribute("listaUsuarios", result.objects);

        return "UsuarioIndex";
    }

    @GetMapping("Form/{IdUsuario}")
    public String Form(@PathVariable int IdUsuario, Model model) {
        if (IdUsuario == 0) {//Agregar un usuario nuevo y dirección
            UsuarioDireccion usuarioDireccion = new UsuarioDireccion();
            usuarioDireccion.Usuario = new Usuario();
            usuarioDireccion.Usuario.Rol = new Rol();
            usuarioDireccion.Direccion = new Direccion();
            usuarioDireccion.Direccion.Colonia = new Colonia();

            model.addAttribute("roles", rolDAOImplementation.GetAll().object);
            model.addAttribute("paises", paisDAOImplementation.GetAll().correct ? paisDAOImplementation.GetAll().object : null);
            model.addAttribute("usuarioDireccion", usuarioDireccion);
            return "UsuarioForm";
        } else {
            Result result = usuarioDAOImplementation.DireccionesByIdUsuario(IdUsuario);
            model.addAttribute("usuarioDirecciones", result.object);
            return "UsuarioDetail";
        }

    }

    @GetMapping("/FormEditable")
    public String FormEditable(Model model, @RequestParam int IdUsuario, @RequestParam(required = false) Integer IdDireccion) {
        if (IdDireccion == null) {
            //Editar usuario
            UsuarioDireccion usuarioDireccion = new UsuarioDireccion();
            usuarioDireccion = (UsuarioDireccion) usuarioDAOImplementation.UsuarioById(IdUsuario).object;
//            usuarioDireccion.Usuario = new Usuario();
//            usuarioDireccion.Usuario.setIdUsuario(IdUsuario);
            usuarioDireccion.Direccion = new Direccion();
            usuarioDireccion.Direccion.setIdDireccion(-1);
            model.addAttribute("usuarioDireccion", usuarioDireccion);
            model.addAttribute("roles", rolDAOImplementation.GetAll().object);

        } else if (IdDireccion == 0) {
            //Agregar Direccion
            UsuarioDireccion usuarioDireccion = new UsuarioDireccion();
            usuarioDireccion.Usuario = new Usuario();
            usuarioDireccion.Usuario.setIdUsuario(IdUsuario);
            usuarioDireccion.Direccion = new Direccion();
            usuarioDireccion.Direccion.setIdDireccion(0);
            model.addAttribute("usuarioDireccion", usuarioDireccion);
            model.addAttribute("paises", paisDAOImplementation.GetAll().correct ? paisDAOImplementation.GetAll().object : null);

        } else {
            // Editar dirección
            UsuarioDireccion usuarioDireccion = new UsuarioDireccion();
            usuarioDireccion.Usuario = new Usuario();
            usuarioDireccion.Usuario.setIdUsuario(IdUsuario);
            usuarioDireccion.Direccion = new Direccion();
            usuarioDireccion.Direccion.setIdDireccion(IdDireccion);
            usuarioDireccion.Direccion = (Direccion) direccionDaOImplementation.GetByIdDireccion(IdDireccion).object;

            model.addAttribute("usuarioDireccion", usuarioDireccion);
            model.addAttribute("paises", paisDAOImplementation.GetAll().correct ? paisDAOImplementation.GetAll().object : null);
            Result estado = estadoDAOImplementation.EstadoByIdPais(usuarioDireccion.Direccion.Colonia.Municipio.Estado.Pais.getIdPais());
            model.addAttribute("estados", estado.objects);
            Result municipio = municipioDAOImplementation.MunicipioByIdEstado(usuarioDireccion.Direccion.Colonia.Municipio.Estado.getIdEstado());
            model.addAttribute("municipios", municipio.objects);
            model.addAttribute("colonias", coloniaDAOImplementation.ColoniaByIdMunicipio(usuarioDireccion.Direccion.Colonia.Municipio.getIdMunicipio()).objects);

        }
        return "UsuarioForm";
    }

    @PostMapping("Form")
    public String Form(@Valid @ModelAttribute UsuarioDireccion usuarioDireccion, BindingResult BindingResult, @RequestParam MultipartFile imagenFile, Model model) {

//        if (BindingResult.hasErrors()) {
//
//            model.addAttribute("usuarioDireccion", usuarioDireccion);
//            return "UsuarioForm";
//
//        }
        try {
            if (!imagenFile.isEmpty()) {
                byte[] bytes = imagenFile.getBytes();
                String imgBase64 = Base64.getEncoder().encodeToString(bytes);
                usuarioDireccion.Usuario.setImagen(imgBase64);
            }

        } catch (Exception ex) {
        }

        if (usuarioDireccion.Usuario.getIdUsuario() == 0) {
            usuarioDAOImplementation.Add(usuarioDireccion);
            return "redirect:/Usuario";
        } else {
            if (usuarioDireccion.Direccion.getIdDireccion() == -1) {
                usuarioDAOImplementation.UpdateUsuario(usuarioDireccion.Usuario);
            } else if (usuarioDireccion.Direccion.getIdDireccion() == 0) {
                direccionDaOImplementation.AddDireccion(usuarioDireccion);
                System.out.println("Agregar dirección");

            } else {
                direccionDaOImplementation.UpdateDireccion(usuarioDireccion.Direccion);
                System.out.println("Actualiza direccion");
            }
            return "redirect:/Usuario/Form/" + usuarioDireccion.Usuario.getIdUsuario();
        }

    }

    @GetMapping("EstadoByIdPais/{IdPais}")
    @ResponseBody
    public Result EstadoByIdPais(@PathVariable int IdPais) {
        Result result = estadoDAOImplementation.EstadoByIdPais(IdPais);

        return result;
    }

    @GetMapping("MunicipioByIdEstado/{IdEstado}")
    @ResponseBody
    public Result MunicipioByIdEstado(@PathVariable int IdEstado) {
        Result result = municipioDAOImplementation.MunicipioByIdEstado(IdEstado);

        return result;
    }

    @GetMapping("ColoniaByIdMunicipio/{IdMunicipio}")
    @ResponseBody
    public Result ColoniaByIdMunicipio(@PathVariable int IdMunicipio) {
        Result result = coloniaDAOImplementation.ColoniaByIdMunicipio(IdMunicipio);

        return result;
    }

    @GetMapping("/DelateDireccion")
    public String DelateDireccion(@RequestParam int IdDireccion) {
        direccionDaOImplementation.DelateDireccion(IdDireccion);
        return "redirect:/Usuario/index";
    }

    @GetMapping("/DelateUsuario")
    public String DelateUsuario(@RequestParam int IdUsuario) {
        usuarioDAOImplementation.DelateUsuario(IdUsuario);
        return "redirect:/Usuario/index";
    }
    
    @PostMapping("/cambiarEstatus")
    @ResponseBody
    public Result UpdateStatusByIdUsuario(@RequestParam int IdUsuario, @RequestParam int Status){
        
        return usuarioDAOImplementation.UpdateStatusByIdUsuario(IdUsuario, Status);
        
    }
    

}
