package com.digis01.HAriasProgramacionNCapas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HAriasProgramacionNCapasApplicationTests {

	@Test
	void contextLoads() {
	}

}
